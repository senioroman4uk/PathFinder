﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using PathFinder.Trips.WebApi.Models;

namespace PathFinder.Trips.WebApi.Extensions
{
    internal static class LocationModelExtensions
    {
        private const char Delimiter = '|';

        private static string ToLatLongString(this GooglePlaceModel place)
        {
            if (place.Geometry == null) return string.Empty;

            return string.Format("{0},{1}", place.Geometry.Location.Lat, place.Geometry.Location.Lng);
        }

        public static string PrepareWaypointsRequestString(this IEnumerable<GooglePlaceModel> waypoints)
        {
            return waypoints.Aggregate(string.Empty, (str, waypoint) => str += waypoint.ToLatLongString() + Delimiter).TrimEnd(Delimiter);
        }
    }
}
