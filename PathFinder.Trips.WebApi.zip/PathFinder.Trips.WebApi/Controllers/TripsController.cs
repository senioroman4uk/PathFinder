﻿using System.Collections.Generic;
using System.Web.Http;
using System.Web.Http.Results;
using PathFinder.Trips.WebApi.Constants;
using PathFinder.Trips.WebApi.Models;
using PathFinder.Trips.WebApi.Queries;

namespace PathFinder.Trips.WebApi.Controllers
{
    [RoutePrefix(TripsRouteConstants.TripsControllerRoutePrefix)]
    public class TripsController : ApiController
    {
        private IDistanceMatrixQuery _distanceMatrixQuery;

        public TripsController(IDistanceMatrixQuery distanceMatrixQuery)
        {
            _distanceMatrixQuery = distanceMatrixQuery;
        }

        [HttpPost]
        [Route(TripsRouteConstants.CreateTrip)]
        public IHttpActionResult CreateTrip(TripReadModel model)
        {
            if (model.Route == null)
            {
                var waypoints = new List<GooglePlaceModel>(model.WayPoints);
                waypoints.Insert(0, model.StartPoint);
                waypoints.Add(model.EndPoint);

                _distanceMatrixQuery.GetDistanceMatrix(waypoints);
                return BadRequest();
            }
                
            return BadRequest();
        }
    }
}
