﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net.Http;
using System.Text;
using System.Threading.Tasks;
using PathFinder.Trips.WebApi.Extensions;
using PathFinder.Trips.WebApi.Models;

namespace PathFinder.Trips.WebApi.Queries
{
    internal class DistanceMatrixQuery : IDistanceMatrixQuery
    {
        private const string DistanseMatrixUrl = "https://maps.googleapis.com/maps/api/distancematrix/json?origins={0}&destinations={1}&key={2}";

        private HttpClient _httpClient;

        public DistanceMatrixQuery(HttpClient httpClient)
        {
            _httpClient = httpClient;
        }

        public double[,] GetDistanceMatrix(IEnumerable<GooglePlaceModel> waypoints)
        {
            string requestWaypoints = waypoints.PrepareWaypointsRequestString();

            return new double[1,1];
        }
    }

    public interface IDistanceMatrixQuery
    {
        double[,] GetDistanceMatrix(IEnumerable<GooglePlaceModel> waypoints);
    }
}
