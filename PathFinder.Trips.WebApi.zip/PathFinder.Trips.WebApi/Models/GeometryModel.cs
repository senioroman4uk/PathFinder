﻿namespace PathFinder.Trips.WebApi.Models
{
    public class GeometryModel
    {
        public LocationModel Location { get; set; }
    }
}
